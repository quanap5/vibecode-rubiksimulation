/**
 * Move Generator - Generates move buttons based on cube size
 */

import { MOVES } from '../core/constants.js';

export class MoveGenerator {
    /**
     * Generate HTML for move buttons based on cube size
     * @param {number} cubeSize - Size of the cube (2-5)
     * @returns {string} HTML string of buttons
     */
    static generateMoveButtons(cubeSize) {
        let buttons = '';
        
        // Basic moves (all cube sizes)
        MOVES.BASIC.forEach(move => {
            buttons += this.createMoveButtonGroup(move);
        });
        
        // Inner layer moves for 4x4 and 5x5
        if (cubeSize >= 4) {
            buttons += this.createSectionLabel('Inner Layers');
            MOVES.BASIC.forEach(move => {
                buttons += `
                    <button class="move-btn" data-move="${move}w">${move}w</button>
                    <button class="move-btn" data-move="${move}w'">${move}w'</button>
                    <button class="move-btn" data-move="2${move}">2${move}</button>
                `;
            });
        }
        
        // Slice moves for odd cubes (3x3, 5x5)
        if (cubeSize % 2 === 1 && cubeSize >= 3) {
            buttons += this.createSectionLabel('Slice Moves');
            MOVES.SLICES.forEach(move => {
                buttons += this.createMoveButtonGroup(move);
            });
        }
        
        return buttons;
    }

    /**
     * Create a group of 3 buttons for a move (normal, prime, double)
     */
    static createMoveButtonGroup(move) {
        return `
            <button class="move-btn" data-move="${move}">${move}</button>
            <button class="move-btn" data-move="${move}'">${move}'</button>
            <button class="move-btn" data-move="${move}2">${move}2</button>
        `;
    }

    /**
     * Create a section label spanning all columns
     */
    static createSectionLabel(text) {
        return `<div class="section-label" style="grid-column: span 3; margin-top: 12px;">${text}</div>`;
    }

    /**
     * Get available moves for scrambling based on cube size
     * @param {number} cubeSize - Size of the cube
     * @returns {string[]} Array of move strings
     */
    static getScrambleMoves(cubeSize) {
        let moves = [];
        
        // Basic moves with prime variants
        MOVES.BASIC.forEach(move => {
            moves.push(move, move + "'");
        });
        
        // Add wide moves for larger cubes
        if (cubeSize >= 4) {
            MOVES.BASIC.forEach(move => {
                moves.push(move + "w", move + "w'");
            });
        }
        
        return moves;
    }

    /**
     * Calculate scramble length based on cube size
     * @param {number} cubeSize - Size of the cube
     * @returns {number} Number of moves to scramble
     */
    static getScrambleLength(cubeSize) {
        return 15 + (cubeSize * 5);
    }
}

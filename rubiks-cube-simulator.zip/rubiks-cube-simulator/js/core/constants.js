/**
 * Rubik's Cube Simulator - Constants & Configuration
 * Central place for all configuration values
 */

export const CONFIG = {
    // Default cube settings
    DEFAULT_SIZE: 3,
    MIN_SIZE: 2,
    MAX_SIZE: 5,
    
    // Animation settings
    DEFAULT_ANIMATION_SPEED: 300,
    MIN_ANIMATION_SPEED: 100,
    MAX_ANIMATION_SPEED: 800,
    SCRAMBLE_SPEED_MULTIPLIER: 0.3,
    SOLVE_SPEED_MULTIPLIER: 0.5,
    
    // Scramble settings
    BASE_SCRAMBLE_LENGTH: 15,
    SCRAMBLE_LENGTH_PER_SIZE: 5,
    
    // Camera settings
    BASE_CAMERA_DISTANCE: 6,
    CAMERA_DISTANCE_PER_SIZE: 2.5,
    
    // Cube geometry
    CUBELET_SIZE: 0.93,
    LAYER_TOLERANCE: 0.1,
};

// Cube face colors (Three.js hex format)
export const COLORS = {
    front: 0x00d95f,   // Green
    back: 0x0051ff,    // Blue
    right: 0xff2b2b,   // Red
    left: 0xff8c00,    // Orange
    top: 0xffffff,     // White
    bottom: 0xffd500,  // Yellow
    inside: 0x111118,  // Dark inside
};

// Move definitions
export const MOVES = {
    // Basic moves
    BASIC: ['U', 'D', 'F', 'B', 'R', 'L'],
    
    // Slice moves (for odd cubes)
    SLICES: ['M', 'E', 'S'],
    
    // Move modifiers
    PRIME: "'",
    DOUBLE: "2",
    WIDE: "w",
};

// Keyboard mappings
export const KEY_MAP = {
    'r': 'R', 'l': 'L', 'u': 'U', 
    'd': 'D', 'f': 'F', 'b': 'B',
    'm': 'M', 'e': 'E', 's': 'S'
};

// Move axis and direction mappings
export const MOVE_DEFINITIONS = {
    'R': { axis: 'x', direction: 1, angle: -Math.PI / 2 },
    'L': { axis: 'x', direction: -1, angle: Math.PI / 2 },
    'U': { axis: 'y', direction: 1, angle: -Math.PI / 2 },
    'D': { axis: 'y', direction: -1, angle: Math.PI / 2 },
    'F': { axis: 'z', direction: 1, angle: -Math.PI / 2 },
    'B': { axis: 'z', direction: -1, angle: Math.PI / 2 },
    'M': { axis: 'x', direction: 0, angle: Math.PI / 2 },
    'E': { axis: 'y', direction: 0, angle: Math.PI / 2 },
    'S': { axis: 'z', direction: 0, angle: -Math.PI / 2 },
};

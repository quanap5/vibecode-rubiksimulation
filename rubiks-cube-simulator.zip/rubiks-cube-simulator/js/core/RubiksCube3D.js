/**
 * Rubik's Cube 3D - Core cube rendering and logic
 * Handles Three.js scene, cube creation, and move animations
 */

import { CONFIG, COLORS, MOVE_DEFINITIONS } from './constants.js';

export class RubiksCube3D {
    constructor(canvas, size = CONFIG.DEFAULT_SIZE) {
        this.canvas = canvas;
        this.cubeSize = size;
        this.cubelets = [];
        this.isAnimating = false;
        this.animationSpeed = CONFIG.DEFAULT_ANIMATION_SPEED;
        this.moveHistory = [];
        this.colors = COLORS;

        this.initScene();
        this.createCube();
        this.setupControls();
        this.animate();
    }

    /**
     * Initialize Three.js scene, camera, renderer, and lights
     */
    initScene() {
        // Scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x0d0d14);

        // Camera
        const aspect = this.canvas.clientWidth / this.canvas.clientHeight;
        this.camera = new THREE.PerspectiveCamera(40, aspect, 0.1, 1000);
        this.camera.position.set(6, 5, 7);
        this.camera.lookAt(0, 0, 0);

        // Renderer
        this.renderer = new THREE.WebGLRenderer({ 
            canvas: this.canvas, 
            antialias: true 
        });
        this.renderer.setSize(this.canvas.clientWidth, this.canvas.clientHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

        // Lighting
        this.setupLights();

        // Pivot group for layer rotation
        this.pivot = new THREE.Group();
        this.scene.add(this.pivot);

        // Handle resize
        window.addEventListener('resize', () => this.onResize());
        this.onResize();
    }

    /**
     * Setup scene lighting
     */
    setupLights() {
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        this.scene.add(ambientLight);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(10, 15, 10);
        this.scene.add(directionalLight);

        const fillLight = new THREE.DirectionalLight(0x8888ff, 0.3);
        fillLight.position.set(-10, -5, -10);
        this.scene.add(fillLight);
    }

    /**
     * Set cube size and rebuild
     */
    setSize(newSize) {
        this.cubeSize = newSize;
        this.moveHistory = [];
        this.createCube();
        this.updateCameraDistance();
    }

    /**
     * Update camera distance based on cube size
     */
    updateCameraDistance() {
        this.radius = CONFIG.BASE_CAMERA_DISTANCE + (this.cubeSize - 2) * CONFIG.CAMERA_DISTANCE_PER_SIZE;
    }

    /**
     * Create a single cubelet at position (x, y, z)
     */
    createCubelet(x, y, z) {
        const size = CONFIG.CUBELET_SIZE;
        const n = this.cubeSize;
        const half = (n - 1) / 2;
        const maxPos = half;
        const minPos = -half;
        
        const geometry = new THREE.BoxGeometry(size, size, size);
        
        // Determine which faces are external
        const isRight = Math.abs(x - maxPos) < 0.01;
        const isLeft = Math.abs(x - minPos) < 0.01;
        const isTop = Math.abs(y - maxPos) < 0.01;
        const isBottom = Math.abs(y - minPos) < 0.01;
        const isFront = Math.abs(z - maxPos) < 0.01;
        const isBack = Math.abs(z - minPos) < 0.01;
        
        // Create materials for each face
        const materials = [
            this.createFaceMaterial(isRight ? this.colors.right : this.colors.inside),
            this.createFaceMaterial(isLeft ? this.colors.left : this.colors.inside),
            this.createFaceMaterial(isTop ? this.colors.top : this.colors.inside),
            this.createFaceMaterial(isBottom ? this.colors.bottom : this.colors.inside),
            this.createFaceMaterial(isFront ? this.colors.front : this.colors.inside),
            this.createFaceMaterial(isBack ? this.colors.back : this.colors.inside),
        ];

        const cubelet = new THREE.Mesh(geometry, materials);
        cubelet.position.set(x, y, z);
        
        return cubelet;
    }

    /**
     * Create material for a cubelet face
     */
    createFaceMaterial(color) {
        return new THREE.MeshStandardMaterial({ 
            color: color,
            roughness: 0.3,
            metalness: 0.1
        });
    }

    /**
     * Create the entire cube
     */
    createCube() {
        // Clear existing cubelets
        this.cubelets.forEach(c => {
            this.scene.remove(c);
            this.pivot.remove(c);
        });
        this.cubelets = [];

        const n = this.cubeSize;
        const half = (n - 1) / 2;

        // Create n×n×n cubelets (skip internal ones)
        for (let x = 0; x < n; x++) {
            for (let y = 0; y < n; y++) {
                for (let z = 0; z < n; z++) {
                    // Skip internal cubelets (not visible)
                    if (x > 0 && x < n-1 && y > 0 && y < n-1 && z > 0 && z < n-1) {
                        continue;
                    }
                    
                    const cubelet = this.createCubelet(x - half, y - half, z - half);
                    this.cubelets.push(cubelet);
                    this.scene.add(cubelet);
                }
            }
        }
        
        this.updateCameraDistance();
    }

    /**
     * Setup mouse/touch controls for rotating the view
     */
    setupControls() {
        let isDragging = false;
        let previousMousePosition = { x: 0, y: 0 };
        this.spherical = { theta: Math.PI / 4, phi: Math.PI / 6 };
        this.radius = 10;
        this.updateCameraDistance();

        const onDragStart = (x, y) => {
            if (this.isAnimating) return;
            isDragging = true;
            previousMousePosition = { x, y };
        };

        const onDragMove = (x, y) => {
            if (!isDragging) return;

            const deltaX = x - previousMousePosition.x;
            const deltaY = y - previousMousePosition.y;

            this.spherical.theta -= deltaX * 0.01;
            this.spherical.phi += deltaY * 0.01;
            this.spherical.phi = Math.max(0.1, Math.min(Math.PI - 0.1, this.spherical.phi));

            previousMousePosition = { x, y };
        };

        const onDragEnd = () => {
            isDragging = false;
        };

        // Mouse events
        this.canvas.addEventListener('mousedown', (e) => onDragStart(e.clientX, e.clientY));
        document.addEventListener('mousemove', (e) => onDragMove(e.clientX, e.clientY));
        document.addEventListener('mouseup', onDragEnd);

        // Touch events
        this.canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            onDragStart(e.touches[0].clientX, e.touches[0].clientY);
        });
        document.addEventListener('touchmove', (e) => {
            if (isDragging) onDragMove(e.touches[0].clientX, e.touches[0].clientY);
        });
        document.addEventListener('touchend', onDragEnd);
    }

    /**
     * Handle window resize
     */
    onResize() {
        const rect = this.canvas.parentElement.getBoundingClientRect();
        const width = rect.width;
        const height = rect.height;

        this.canvas.width = width;
        this.canvas.height = height;

        this.camera.aspect = width / height;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(width, height);
    }

    /**
     * Get cubelets in a specific layer
     */
    getLayerCubelets(axis, layer) {
        const tolerance = CONFIG.LAYER_TOLERANCE;
        return this.cubelets.filter(cubelet => {
            const pos = cubelet.position;
            switch (axis) {
                case 'x': return Math.abs(pos.x - layer) < tolerance;
                case 'y': return Math.abs(pos.y - layer) < tolerance;
                case 'z': return Math.abs(pos.z - layer) < tolerance;
            }
        });
    }

    /**
     * Get the outer layer position for a face
     */
    getOuterLayer(face) {
        const half = (this.cubeSize - 1) / 2;
        switch (face) {
            case 'R': return half;
            case 'L': return -half;
            case 'U': return half;
            case 'D': return -half;
            case 'F': return half;
            case 'B': return -half;
            default: return 0;
        }
    }

    /**
     * Animate a layer rotation
     */
    async rotateLayer(axis, layer, angle, duration) {
        if (this.isAnimating) return;
        this.isAnimating = true;

        const layerCubelets = this.getLayerCubelets(axis, layer);
        
        // Move cubelets to pivot
        layerCubelets.forEach(cubelet => {
            this.scene.remove(cubelet);
            this.pivot.add(cubelet);
        });

        // Reset pivot
        this.pivot.rotation.set(0, 0, 0);

        return new Promise(resolve => {
            const startTime = performance.now();
            
            const animateFrame = (currentTime) => {
                const elapsed = currentTime - startTime;
                const progress = Math.min(elapsed / duration, 1);
                
                // Smooth easing (ease-out cubic)
                const eased = 1 - Math.pow(1 - progress, 3);
                const currentAngle = angle * eased;

                // Apply rotation
                this.pivot.rotation[axis] = currentAngle;

                if (progress < 1) {
                    requestAnimationFrame(animateFrame);
                } else {
                    // Finish animation
                    this.finishRotation(layerCubelets, axis, angle);
                    this.isAnimating = false;
                    resolve();
                }
            };

            requestAnimationFrame(animateFrame);
        });
    }

    /**
     * Rotate multiple layers at once (for wide moves)
     */
    async rotateMultipleLayers(axis, layers, angle, duration) {
        if (this.isAnimating) return;
        this.isAnimating = true;

        let allLayerCubelets = [];
        layers.forEach(layer => {
            const cubelets = this.getLayerCubelets(axis, layer);
            cubelets.forEach(c => {
                if (!allLayerCubelets.includes(c)) {
                    allLayerCubelets.push(c);
                }
            });
        });
        
        // Move cubelets to pivot
        allLayerCubelets.forEach(cubelet => {
            this.scene.remove(cubelet);
            this.pivot.add(cubelet);
        });

        this.pivot.rotation.set(0, 0, 0);

        return new Promise(resolve => {
            const startTime = performance.now();
            
            const animateFrame = (currentTime) => {
                const elapsed = currentTime - startTime;
                const progress = Math.min(elapsed / duration, 1);
                const eased = 1 - Math.pow(1 - progress, 3);
                const currentAngle = angle * eased;

                this.pivot.rotation[axis] = currentAngle;

                if (progress < 1) {
                    requestAnimationFrame(animateFrame);
                } else {
                    this.finishRotation(allLayerCubelets, axis, angle);
                    this.isAnimating = false;
                    resolve();
                }
            };

            requestAnimationFrame(animateFrame);
        });
    }

    /**
     * Finish rotation - update cubelet positions
     */
    finishRotation(layerCubelets, axis, angle) {
        layerCubelets.forEach(cubelet => {
            // Get world position
            const worldPos = new THREE.Vector3();
            cubelet.getWorldPosition(worldPos);
            
            // Get world quaternion
            const worldQuat = new THREE.Quaternion();
            cubelet.getWorldQuaternion(worldQuat);

            // Remove from pivot
            this.pivot.remove(cubelet);

            // Round to nearest valid grid position
            const roundToGrid = (val) => Math.round(val * 2) / 2;
            
            cubelet.position.set(
                roundToGrid(worldPos.x),
                roundToGrid(worldPos.y),
                roundToGrid(worldPos.z)
            );
            
            // Apply rotation
            cubelet.quaternion.copy(worldQuat);

            // Add back to scene
            this.scene.add(cubelet);
        });

        // Reset pivot
        this.pivot.rotation.set(0, 0, 0);
    }

    /**
     * Apply a move using standard notation
     */
    async applyMove(move, record = true) {
        // Parse move notation
        let baseMove = move.replace("'", "").replace("2", "").replace("w", "");
        const isPrime = move.includes("'");
        const isDouble = move.includes("2");
        const isWide = move.includes("w");
        
        // Check for numbered layer prefix
        let layerNum = 1;
        const numMatch = baseMove.match(/^(\d+)/);
        if (numMatch) {
            layerNum = parseInt(numMatch[1]);
            baseMove = baseMove.replace(/^\d+/, '');
        }
        
        const moveDef = MOVE_DEFINITIONS[baseMove.toUpperCase()];
        if (!moveDef) return;
        
        const half = (this.cubeSize - 1) / 2;
        let { axis, direction, angle } = moveDef;
        
        // Calculate layer position
        let layer;
        if (direction === 0) {
            layer = 0; // Middle layer
        } else if (direction === 1) {
            layer = half - (layerNum - 1);
        } else {
            layer = -half + (layerNum - 1);
        }

        if (isPrime) angle = -angle;
        if (isDouble) angle *= 2;

        // For wide moves, rotate multiple layers
        if (isWide && this.cubeSize > 3) {
            const layers = [];
            for (let i = 0; i < 2; i++) {
                if (direction === 1) {
                    layers.push(half - i);
                } else {
                    layers.push(-half + i);
                }
            }
            await this.rotateMultipleLayers(axis, layers, angle, this.animationSpeed);
        } else {
            await this.rotateLayer(axis, layer, angle, this.animationSpeed);
        }
        
        if (record) {
            this.moveHistory.push(move);
        }
    }

    /**
     * Get the inverse of a move
     */
    getInverse(move) {
        if (move.includes("2")) return move;
        if (move.includes("'")) return move.replace("'", "");
        return move + "'";
    }

    /**
     * Reset cube to solved state
     */
    reset() {
        this.createCube();
        this.moveHistory = [];
    }

    /**
     * Main animation loop
     */
    animate() {
        requestAnimationFrame(() => this.animate());

        // Update camera from spherical coordinates
        this.camera.position.x = this.radius * Math.sin(this.spherical.phi) * Math.sin(this.spherical.theta);
        this.camera.position.y = this.radius * Math.cos(this.spherical.phi);
        this.camera.position.z = this.radius * Math.sin(this.spherical.phi) * Math.cos(this.spherical.theta);
        this.camera.lookAt(0, 0, 0);

        this.renderer.render(this.scene, this.camera);
    }
}

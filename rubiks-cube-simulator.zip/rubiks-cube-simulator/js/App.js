/**
 * Rubik's Cube App - Main application controller
 * Coordinates between UI, cube logic, and user interactions
 */

import { CONFIG, KEY_MAP } from './core/constants.js';
import { RubiksCube3D } from './core/RubiksCube3D.js';
import { UIController } from './ui/UIController.js';
import { MoveGenerator } from './utils/MoveGenerator.js';

export class CubeApp {
    constructor() {
        this.currentSize = CONFIG.DEFAULT_SIZE;
        this.isProcessing = false;
        
        // Initialize cube
        this.cube = new RubiksCube3D(
            document.getElementById('cubeCanvas'), 
            this.currentSize
        );
        
        // Initialize UI controller
        this.ui = new UIController();
        
        // Setup
        this.generateMoveButtons();
        this.setupEventListeners();
    }

    /**
     * Generate move buttons based on current cube size
     */
    generateMoveButtons() {
        const buttonsHtml = MoveGenerator.generateMoveButtons(this.currentSize);
        this.ui.setMoveButtons(buttonsHtml);
        
        // Rebind move button events
        this.ui.onMoveButtonClick(async (move) => {
            if (this.isProcessing || this.cube.isAnimating) return;
            await this.cube.applyMove(move);
            this.ui.updateHistory(this.cube.moveHistory);
        });
    }

    /**
     * Change cube size
     */
    changeSize(newSize) {
        if (this.isProcessing || this.cube.isAnimating) return;
        if (newSize === this.currentSize) return;
        
        this.currentSize = newSize;
        this.cube.setSize(newSize);
        this.generateMoveButtons();
        this.ui.updateHistory(this.cube.moveHistory);
        this.ui.setStatus(`${newSize}×${newSize} Ready`);
        this.ui.setActiveSize(newSize);
    }

    /**
     * Setup all event listeners
     */
    setupEventListeners() {
        // Size selector
        this.ui.onSizeChange((size) => this.changeSize(size));

        // Speed slider
        this.ui.onSpeedChange((speed) => {
            this.cube.animationSpeed = speed;
        });

        // Action buttons
        this.ui.onScramble(() => this.scramble());
        this.ui.onSolve(() => this.solve());
        this.ui.onReset(() => this.reset());

        // Keyboard controls
        this.ui.onKeyPress(async (e) => {
            if (this.isProcessing || this.cube.isAnimating) return;
            
            const key = e.key.toLowerCase();
            
            if (KEY_MAP[key]) {
                e.preventDefault();
                const move = e.shiftKey ? KEY_MAP[key] + "'" : KEY_MAP[key];
                await this.cube.applyMove(move);
                this.ui.updateHistory(this.cube.moveHistory);
            }
        });
    }

    /**
     * Scramble the cube
     */
    async scramble() {
        if (this.isProcessing || this.cube.isAnimating) return;
        this.isProcessing = true;
        this.ui.setStatus('Scrambling...');
        this.ui.setButtonsDisabled(true);

        // Reset cube first
        this.cube.reset();
        this.ui.updateHistory(this.cube.moveHistory);

        // Get scramble parameters
        const scrambleLength = MoveGenerator.getScrambleLength(this.currentSize);
        const moves = MoveGenerator.getScrambleMoves(this.currentSize);
        
        // Store original speed and use faster speed for scramble
        const originalSpeed = this.cube.animationSpeed;
        this.cube.animationSpeed = Math.min(80, originalSpeed * CONFIG.SCRAMBLE_SPEED_MULTIPLIER);

        // Perform scramble
        let lastFace = '';
        for (let i = 0; i < scrambleLength; i++) {
            let move;
            do {
                move = moves[Math.floor(Math.random() * moves.length)];
            } while (move[0] === lastFace);
            
            this.ui.setStatus(`Scrambling... ${i + 1}/${scrambleLength}`);
            await this.cube.applyMove(move);
            lastFace = move[0];
        }

        // Restore settings
        this.cube.animationSpeed = originalSpeed;
        this.ui.updateHistory(this.cube.moveHistory);
        this.ui.setStatus('Scrambled!');
        this.ui.setButtonsDisabled(false);
        this.isProcessing = false;
    }

    /**
     * Solve the cube (reverse all moves)
     */
    async solve() {
        if (this.isProcessing || this.cube.isAnimating) return;
        
        if (this.cube.moveHistory.length === 0) {
            this.ui.setStatus('Already solved!');
            return;
        }

        this.isProcessing = true;
        this.ui.setStatus('Solving...');
        this.ui.setButtonsDisabled(true);

        // Generate solution (reverse of move history)
        const solution = [...this.cube.moveHistory]
            .reverse()
            .map(m => this.cube.getInverse(m));
        
        // Store original speed
        const originalSpeed = this.cube.animationSpeed;
        this.cube.animationSpeed = Math.min(150, originalSpeed * CONFIG.SOLVE_SPEED_MULTIPLIER);

        // Apply solution
        for (let i = 0; i < solution.length; i++) {
            this.ui.setStatus(`Solving... ${i + 1}/${solution.length}`);
            await this.cube.applyMove(solution[i], false);
        }

        // Clear history and restore settings
        this.cube.moveHistory = [];
        this.cube.animationSpeed = originalSpeed;
        this.ui.updateHistory(this.cube.moveHistory);
        this.ui.setStatus('✓ Solved!');
        this.ui.setButtonsDisabled(false);
        this.isProcessing = false;
    }

    /**
     * Reset cube to solved state
     */
    reset() {
        if (this.isProcessing || this.cube.isAnimating) return;
        this.cube.reset();
        this.ui.updateHistory(this.cube.moveHistory);
        this.ui.setStatus(`${this.currentSize}×${this.currentSize} Ready`);
    }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.cubeApp = new CubeApp();
});

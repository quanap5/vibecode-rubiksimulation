/**
 * UI Controller - Handles all DOM interactions and UI updates
 */

export class UIController {
    constructor() {
        // Cache DOM elements
        this.elements = {
            status: document.getElementById('status'),
            moveHistory: document.getElementById('moveHistory'),
            speedSlider: document.getElementById('speedSlider'),
            speedValue: document.getElementById('speedValue'),
            moveGrid: document.getElementById('moveGrid'),
            scrambleBtn: document.getElementById('scrambleBtn'),
            solveBtn: document.getElementById('solveBtn'),
            resetBtn: document.getElementById('resetBtn'),
        };
    }

    /**
     * Update status display
     */
    setStatus(text) {
        this.elements.status.textContent = text;
    }

    /**
     * Update move history display
     */
    updateHistory(moveHistory) {
        if (moveHistory.length === 0) {
            this.elements.moveHistory.innerHTML = '-';
        } else {
            const last20 = moveHistory.slice(-20);
            this.elements.moveHistory.innerHTML = last20
                .map(m => `<span>${m}</span>`)
                .join('');
        }
    }

    /**
     * Update speed display
     */
    updateSpeedDisplay(speed) {
        this.elements.speedValue.textContent = `${speed}ms`;
    }

    /**
     * Set move buttons HTML
     */
    setMoveButtons(html) {
        this.elements.moveGrid.innerHTML = html;
    }

    /**
     * Get all move buttons
     */
    getMoveButtons() {
        return this.elements.moveGrid.querySelectorAll('.move-btn');
    }

    /**
     * Disable/enable all interactive buttons
     */
    setButtonsDisabled(disabled) {
        document.querySelectorAll('.move-btn, .action-btn, .size-btn').forEach(btn => {
            btn.disabled = disabled;
        });
    }

    /**
     * Update active size button
     */
    setActiveSize(size) {
        document.querySelectorAll('.size-btn').forEach(btn => {
            btn.classList.toggle('active', parseInt(btn.dataset.size) === size);
        });
    }

    /**
     * Get speed slider value
     */
    getSpeed() {
        return parseInt(this.elements.speedSlider.value);
    }

    /**
     * Setup speed slider event
     */
    onSpeedChange(callback) {
        this.elements.speedSlider.addEventListener('input', (e) => {
            const speed = parseInt(e.target.value);
            this.updateSpeedDisplay(speed);
            callback(speed);
        });
    }

    /**
     * Setup size button events
     */
    onSizeChange(callback) {
        document.querySelectorAll('.size-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const size = parseInt(btn.dataset.size);
                callback(size);
            });
        });
    }

    /**
     * Setup action button events
     */
    onScramble(callback) {
        this.elements.scrambleBtn.addEventListener('click', callback);
    }

    onSolve(callback) {
        this.elements.solveBtn.addEventListener('click', callback);
    }

    onReset(callback) {
        this.elements.resetBtn.addEventListener('click', callback);
    }

    /**
     * Setup keyboard events
     */
    onKeyPress(callback) {
        document.addEventListener('keydown', callback);
    }

    /**
     * Setup move button click events
     */
    onMoveButtonClick(callback) {
        this.getMoveButtons().forEach(btn => {
            btn.addEventListener('click', () => {
                const move = btn.dataset.move;
                callback(move);
            });
        });
    }
}
